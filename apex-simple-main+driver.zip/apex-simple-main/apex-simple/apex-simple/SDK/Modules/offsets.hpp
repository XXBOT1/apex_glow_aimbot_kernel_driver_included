#pragma once


#define OFFSET_EntityList			0x1db73e8 
#define OFFSET_LocalPlayer			0x2165e48 						
#define OFFSET_NameList				0xC5D9FD0    
#define OFFSET_VIEWRENDER			0x73df958   
#define OFFSET_MATRIX				0x11a350     

#define OFFSET_NAME					0x0471   
#define OFFSET_TEAM					0x0328 	
#define OFFSET_HEALTH				0x0318
#define OFFSET_SHIELD				0x01a0      
#define OFFSET_LIFE_STATE			0x0680
#define OFFSET_BLEED_OUT_STATE		0x26c0   

#define OFFSET_ORIGIN				0x017c	
#define OFFSET_BONES				0x0d80 + 0x48
#define OFFSET_STUDIOHDR            0xfd0 
#define OFFSET_VISIBLE_TIME			0x196d + 0x3 
#define OFFSET_CAMERAPOS			0x1eb0 		


#define OFFSET_GLOW_ENABLE 0x28C 
#define OFFSET_GLOW_THROUGH_WALLS 0x26c 
#define OFFSET_GLOW_FIX 0x268 
#define OFFSET_GLOW_CONTEXT_ID OFFSET_GLOW_ENABLE 
#define HIGHLIGHT_SETTINGS 0xB943CB0  
#define HIGHLIGHT_TYPE_SIZE 0x34 

