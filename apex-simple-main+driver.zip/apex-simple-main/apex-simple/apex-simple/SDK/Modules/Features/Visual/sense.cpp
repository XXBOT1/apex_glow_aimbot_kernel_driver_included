
#include "Sense.h"
#include <Memory/globals.hpp>

void Sense::runGlow(uintptr_t entity, uintptr_t localplayer, bool isVisible) {

    uint64_t highlightSettingsPtr = typenull::memory->read<uint64_t>(typenull::c_base + 0xB93DFD0);//m_Glow_Highlights
    typenull::memory->write<int>(entity + 0x28C/*m_Glow_Enable*/, 7); // 7 = enabled, 2 = disabled
    typenull::memory->write<int>(entity + 0x26C/*m_Glow_Through_Wall*/, 2); // 2 = enabled, 5 = disabled

    int settingIndex = 65;

    std::array<unsigned char, 4> highlightFunctionBits = {
        101,   // InsideFunction							2
        127, // OutlineFunction: HIGHLIGHT_OUTLINE_OBJECTIVE			125
        46,  // OutlineRadius: size * 255 / 8				64
        90   // (EntityVisible << 6) | State & 0x3F | (AfterPostProcess << 7) 	64
    };

    std::array<float, 3> glowColorRGB = { 0.0f, 1.0f, 0.0f };

    typenull::memory->write<unsigned char>(entity + 0x28C/*m_Glow_Highlight_Id*/ + /*contextId*/1, settingIndex);
    typenull::memory->write<decltype(highlightFunctionBits)>(highlightSettingsPtr + 0x34/*m_Highlight_Type_Size*/ * settingIndex + 0, highlightFunctionBits);


    typenull::memory->write<decltype(glowColorRGB)>(highlightSettingsPtr + 0x34/*m_Highlight_Type_Size*/ * settingIndex + 4, glowColorRGB);
    typenull::memory->write<int>(entity + 0x268/*m_Glow_Fix*/, 0);

}