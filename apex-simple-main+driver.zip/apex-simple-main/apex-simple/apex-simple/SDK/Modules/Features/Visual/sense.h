#pragma once
#include <cstdint>

class Sense {
public:

	static void runGlow(uintptr_t ent, uintptr_t localp, bool isVisible);

};