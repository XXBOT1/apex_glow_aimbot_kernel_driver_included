
#include "player_cache.h"
#include <Memory/globals.hpp>
#include <Modules/offsets.hpp>

bool IsPlayer(uintptr_t ent)
{
	uint64_t name = typenull::memory->read<uint64_t>(ent + OFFSET_NAME);
	return (name == 125780153691248);
}
int GetTeam(uintptr_t ent)
{
	return typenull::memory->read<int>(ent + OFFSET_TEAM);
}

std::vector<EntityCache> CachedPlayerList;

void PlayerCache::updateCache() {

	while (true)
	{
		std::vector<EntityCache> tmplist;
		uint64_t entitylist = typenull::c_base + OFFSET_EntityList;
		//std::cout << "entitylist " << entitylist << std::endl;

		for (int i = 0; i < 128 + 1; i++)
		{
			uint64_t localent = typenull::memory->read<uint64_t>(typenull::c_base + OFFSET_LocalPlayer);
			if (!localent) continue;

			uint64_t centity = typenull::memory->read<uint64_t>(entitylist + (((uint64_t)i + 1) << 5));
			//std::cout << "centity " << centity << std::endl;
			int health = typenull::memory->read<int>(centity + OFFSET_HEALTH);
			if (!IsPlayer(centity)) continue;
			if (health < 1 || GetTeam(centity) == GetTeam(localent)) continue;

			EntityCache EntityCache{ };
			EntityCache.player_entity = centity;
			EntityCache.player_id = i;
			tmplist.push_back(EntityCache);

		}

		CachedPlayerList = tmplist;

		Sleep(1000);
	}
}