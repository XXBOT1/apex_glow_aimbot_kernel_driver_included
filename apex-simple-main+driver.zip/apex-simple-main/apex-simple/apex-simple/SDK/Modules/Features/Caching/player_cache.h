#pragma once

#include <vector>
#include <atomic>
#include <thread>
#include <mutex>
#include <chrono>
#include <Windows.h>

struct EntityCache {
	DWORD64 player_entity;
	int player_id;
};

class PlayerCache {
public:
	// installation fonksiyonunun prototipi
	static void updateCache();
};
extern std::vector<EntityCache> CachedPlayerList;
