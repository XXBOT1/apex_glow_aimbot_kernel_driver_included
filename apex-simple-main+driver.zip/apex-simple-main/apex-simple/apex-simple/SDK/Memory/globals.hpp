#pragma once
#include <mutex>
#include <vector>
#include <atomic>
#include <thread>
#include <chrono>
#include "memory_class.hpp"
#include <memory> // Ensure this is included to use std::unique_ptr

namespace th = std::this_thread;
namespace ch = std::chrono;

namespace typenull {
    extern std::unique_ptr<memory_typenull> memory; // Declaration only, no definition
    extern uintptr_t c_base; // Declare c_base as well, assuming you use it.
}