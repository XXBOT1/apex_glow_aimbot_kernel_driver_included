#include "globals.hpp"


namespace typenull {
    std::unique_ptr<memory_typenull> memory = nullptr; // Definition of the unique_ptr
    uintptr_t c_base = 0; // Definition of c_base, if needed
}