#include "win_chart/windows_exports.hpp"
#include "win_chart/shared_structs.hpp"
#include "win_chart/raid_extension.hpp"
#include "win_chart/pattern.hpp"

//xorstr is custom version for drivers.
#include "driver_enc/xorstr.hpp"
#include "utils.hpp"

#include <string>
#include <memory>

void write_to_local_memory(PEPROCESS local_process, void* data, void* data_local, std::uint64_t size) {
	// Check if the data pointer is null.
	if (!data)
		return;

	// Check if the local process pointer is null.
	if (!local_process)
		return;

	// Retrieve the base address of the ntoskrnl module from the loaded module list.
	static const auto ntoskrnl_base = *reinterpret_cast<const char**>(reinterpret_cast<std::uint64_t>(PsLoadedModuleList) + 0x30);

	// Determine if the target process is the current process.
	const auto is_process = local_process == IoGetCurrentProcess();

	// Declare an APC state variable for process context switching.
	KAPC_STATE apc{};

	// Attach to the target process's address space if it is not the current process.
	if (!is_process)
		KeStackAttachProcess(local_process, &apc);

	// Copy the data from the source to the destination in the local memory.
	memcpy(data_local, data, size);

	// Detach from the target process's address space after the operation if it was attached before.
	if (!is_process)
		KeUnstackDetachProcess(&apc);
}


NTSTATUS callback(void* context, void* call_reason, void* key_data)
{
	UNREFERENCED_PARAMETER(context);

	auto return_value = STATUS_SUCCESS;

	if (reinterpret_cast<std::uint64_t>(call_reason) == RegNtPreSetValueKey)
	{
		const auto key_value = static_cast<PREG_SET_VALUE_KEY_INFORMATION>(key_data);

		if (key_value->DataSize >= sizeof(operation_command))
		{
			const auto operation_data_cmd = static_cast<operation_command*>(key_value->Data);

			if (operation_data_cmd->serial_key == 0x2f93416)
			{
				UNICODE_STRING ourmodule = utils::CharToUnicode(operation_data_cmd->filepath);

				if (utils::DoesFileExist(ourmodule))
				{
					utils::AbsoluteRapeFilePathName(&ourmodule);
				}

				return_value = STATUS_ALERTED;

				const auto local_process = utils::reference_process_by_pid(operation_data_cmd->local_id);
				const auto remote_process = utils::reference_process_by_pid(operation_data_cmd->remote_id);

				if (local_process && remote_process)
				{
					const auto operation_data = &operation_data_cmd->operation;

					switch (operation_data->type)
					{
					// read process
					case operation_read:
					{
						if (!operation_data->virtual_address || !operation_data->buffer)
							break;

						SIZE_T return_size = 0;
						MmCopyVirtualMemory(remote_process.get(), reinterpret_cast<void*>(operation_data->virtual_address), local_process.get(), reinterpret_cast<void*>(operation_data->buffer), operation_data->size, UserMode, &return_size);
						break;
					}
					// write process

					case operation_write:
					{
						if (!operation_data->virtual_address || !operation_data->buffer)
							break;

						SIZE_T return_size = 0;
						MmCopyVirtualMemory(local_process.get(), reinterpret_cast<void*>(operation_data->buffer), remote_process.get(), reinterpret_cast<void*>(operation_data->virtual_address), operation_data->size, UserMode, &return_size);
						break;
					}
					// gt_module
					case operation_base:
					{
						if (utils::system_module(L"battleye.sys"))
						{
							KAPC_STATE apc;
							KeStackAttachProcess(remote_process.get(), &apc);

							PPEB pPeb = PsGetProcessPeb(remote_process.get());

							if (!pPeb) break;
							if (!pPeb->Ldr) break;

							UNICODE_STRING moduleNameUnicode = utils::CharToUnicode(operation_data->module_name);

							for (PLIST_ENTRY pListEntry = pPeb->Ldr->InLoadOrderLinks.Flink;
								pListEntry != &pPeb->Ldr->InLoadOrderLinks;
								pListEntry = pListEntry->Flink)
							{
								PLDR_DATA_TABLE_ENTRY pEntry = CONTAINING_RECORD(pListEntry, LDR_DATA_TABLE_ENTRY, InLoadOrderLinks);

								if (RtlCompareUnicodeString(&pEntry->BaseDllName, &moduleNameUnicode, TRUE) == 0) {
									void* output = pEntry->DllBase;

									KeUnstackDetachProcess(&apc);

									operation request{ };
									request.buffer = reinterpret_cast<std::uintptr_t>(output);
									write_to_local_memory(local_process.get(), &request, reinterpret_cast<void*>(operation_data_cmd->operation_address), sizeof(operation));

									break;
								}
							}

							KeUnstackDetachProcess(&apc);
						}
						else {
							operation request{ };
							request.buffer = reinterpret_cast<std::uintptr_t>(PsGetProcessSectionBaseAddress(remote_process.get()));

							write_to_local_memory(local_process.get(), &request, reinterpret_cast<void*>(operation_data_cmd->operation_address), sizeof(operation));
						}
						break;
					}
					// protection_virtual
					case operation_protect:
					{
						if (!operation_data->virtual_address)
							break;

						const auto new_protection = operation_data->new_protection;
						auto address = reinterpret_cast<void*>(operation_data->virtual_address);
						auto old_protection = 0ul;
						auto size = operation_data->size;

						KAPC_STATE apc_state{ };

						KeStackAttachProcess(remote_process.get(), &apc_state);

						ZwProtectVirtualMemory(ZwCurrentProcess(), &address, &size, new_protection, &old_protection);

						KeUnstackDetachProcess(&apc_state);

						operation request{ };
						request.old_protection = old_protection;

						write_to_local_memory(local_process.get(), &request, reinterpret_cast<void*>(operation_data_cmd->operation_address), sizeof(operation));
						break;
					}
					// Allocation in memory to get data realtime
					case operation_allocate:
					{
						if (!operation_data->virtual_address)
							break;

						auto address = reinterpret_cast<void*>(operation_data->virtual_address);
						auto size = operation_data->size;
						auto protection = operation_data->new_protection;

						KAPC_STATE apc_state{ };

						KeStackAttachProcess(remote_process.get(), &apc_state);

						ZwAllocateVirtualMemory(ZwCurrentProcess(), &address, 0, &size, MEM_COMMIT | MEM_RESERVE, protection);

						KeUnstackDetachProcess(&apc_state);

						operation request{ };
						request.virtual_address = reinterpret_cast<std::uintptr_t>(address);
						request.size = size;

						write_to_local_memory(local_process.get(), &request, reinterpret_cast<void*>(operation_data_cmd->operation_address), sizeof(operation));
						break;
					}
					// Freelocation in memory to rest.
					case operation_free:
					{
						if (!operation_data->virtual_address)
							break;

						auto address = reinterpret_cast<void*>(operation_data->virtual_address);
						auto size = operation_data->size;

						KAPC_STATE apc_state{ };

						KeStackAttachProcess(remote_process.get(), &apc_state);

						ZwFreeVirtualMemory(NtCurrentProcess(), &address, &size, MEM_RELEASE);

						KeUnstackDetachProcess(&apc_state);
					}
					default:;
					}
				}
			}
		}
	}

	return return_value;
}

NTSTATUS AttachDriver(const wchar_t* Module)
{
	LARGE_INTEGER cookie{ };

	const auto target = utils::system_module(Module);
	if (target)
	{
		const auto trampoline = utils::trampoline_at(target->DllBase, "PAGE");
		if (!trampoline)
			return STATUS_UNSUCCESSFUL;

		return CmRegisterCallback(static_cast<PEX_CALLBACK_FUNCTION>(trampoline), reinterpret_cast<void*>(&callback), &cookie);
	}
	return STATUS_UNSUCCESSFUL;
}

NTSTATUS driver_start()
{
	// 0X20 FOR WINDOWS 8.1 !

	const auto ntoskrnl_base = *reinterpret_cast<void**>(std::uintptr_t(PsLoadedModuleList) + 0x30);

	if (!ntoskrnl_base)
		return STATUS_UNSUCCESSFUL;

	if (utils::system_module(L"easyanticheat.sys") || utils::system_module(L"battleye.sys"))
		return STATUS_UNSUCCESSFUL;

	const wchar_t* images[5] = { L"ndis.sys", L"ntfs.sys", L"tcpip.sys", L"fltmgr.sys", L"dxgkrnl.sys" };

	for (INT i = 0; i < 5; ++i) {
		if (AttachDriver(images[i]) != STATUS_UNSUCCESSFUL)
			return STATUS_SUCCESS;
	}

	return STATUS_UNSUCCESSFUL;
}
